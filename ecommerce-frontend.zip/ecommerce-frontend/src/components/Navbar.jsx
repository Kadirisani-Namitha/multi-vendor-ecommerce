import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav style={{ display: "flex", gap: "20px", padding: "1rem", background: "#f5f5f5" }}>
      <Link to="/">MultiVendor</Link>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/products">Products</Link>
      <Link to="/orders">My Orders</Link> {/* ✅ This is correct */}
      <Link to="/cart">Cart</Link>
      <Link to="/login">Login</Link>
    </nav>
  );
};

export default Navbar;
