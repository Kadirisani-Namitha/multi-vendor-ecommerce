import React, { useEffect, useState } from "react";
import axios from "axios";
import { useCart } from "../context/CartContext";

const Products = () => {
  const [products, setProducts] = useState([]);
  const { addToCart } = useCart();

  useEffect(() => {
    axios.get("http://127.0.0.1:5000/api/products/all")
      .then((res) => setProducts(res.data.products))
      .catch((err) => {
        console.error("Failed to fetch products:", err);
        setProducts([]); // fallback to empty array
      });
  }, []);

  return (
    <div className="grid grid-cols-3 gap-4 p-4">
      {products.length > 0 ? (
        products.map((product) => (
          <div key={product.id} className="border p-4 rounded shadow">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-48 object-cover mb-2"
            />
            <h2 className="text-lg font-semibold">{product.name}</h2>
            <p className="text-sm">{product.description}</p>
            <p className="font-bold">${product.price}</p>
            <button
              onClick={() => addToCart(product)}
              className="mt-2 bg-blue-500 text-white px-4 py-1 rounded"
            >
              Add to Cart
            </button>
          </div>
        ))
      ) : (
        <p>Loading products...</p>
      )}
    </div>
  );
};

export default Products;
