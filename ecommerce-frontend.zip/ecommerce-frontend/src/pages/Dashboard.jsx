import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div>
      <h1>Welcome, {user?.name}!</h1>
      <p>Role: {user?.role}</p>

      {user?.role === "vendor" ? (
        <div>
          <h2>Vendor Dashboard</h2>
          <p>Manage your products, orders, and profile here.</p>
        </div>
      ) : (
        <div>
          <h2>Customer Dashboard</h2>
          <p>Browse products, track orders, and update your account.</p>
        </div>
      )}

      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Dashboard;
