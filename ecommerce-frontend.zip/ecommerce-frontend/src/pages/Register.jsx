// src/pages/Register.jsx
import React, { useState } from "react";

const Register = () => {
  const [email, setEmail] = useState("");

  const handleRegister = () => {
    alert(`Registered with email: ${email}`);
  };

  return (
    <div>
      <h2>Register</h2>
      <input
        type="email"
        placeholder="Enter email"
        onChange={(e) => setEmail(e.target.value)}
      />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
};

export default Register;
